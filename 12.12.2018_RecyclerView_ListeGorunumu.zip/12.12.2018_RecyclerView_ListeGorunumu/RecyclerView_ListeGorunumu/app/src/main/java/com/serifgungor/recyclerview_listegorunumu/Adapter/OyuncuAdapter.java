package com.serifgungor.recyclerview_listegorunumu.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_listegorunumu.Holder.OyuncuHolder;
import com.serifgungor.recyclerview_listegorunumu.Model.Oyuncu;
import com.serifgungor.recyclerview_listegorunumu.R;

import java.util.List;

public class OyuncuAdapter extends RecyclerView.Adapter<OyuncuHolder> {
    List<Oyuncu> oyuncular;
    Context context;


    public OyuncuAdapter(List<Oyuncu> oyuncular){
        this.oyuncular = oyuncular;
    }

    @NonNull
    @Override
    public OyuncuHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Satır görüntüsünün üretildiği metot
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.oyuncu_satiri,null);

        return new OyuncuHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OyuncuHolder holder, int position) {
        holder.tvOyuncuAdSoyad.setText(oyuncular.get(position).getAdsoyad());
        Glide
                .with(holder.itemView.getContext())
                .load(oyuncular.get(position).getResim())
                .into(holder.ivOyuncuResim);
    }

    @Override
    public int getItemCount() {
        return oyuncular.size();
    }
}
