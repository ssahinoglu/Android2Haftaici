package com.serifgungor.recyclerview_listegorunumu.Activity;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_listegorunumu.Adapter.OyuncuAdapter;
import com.serifgungor.recyclerview_listegorunumu.Model.Film;
import com.serifgungor.recyclerview_listegorunumu.Model.Oyuncu;
import com.serifgungor.recyclerview_listegorunumu.R;

import java.util.List;

public class DetayActivity extends AppCompatActivity {

    TextView tvDetaySure,tvDetayTuru,tvDetayYonetmen,tvDetayYapimci,tvDetayTarih,tvFilmadi;
    ImageView ivDetayAfis;
    RecyclerView recyclerView;
    OyuncuAdapter adapter;
    List<Oyuncu> oyuncular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        recyclerView = findViewById(R.id.recyclerViewOyuncular);
        tvDetaySure = findViewById(R.id.tvDetaySure);
        tvDetayTuru = findViewById(R.id.tvDetayTuru);
        tvDetayYonetmen = findViewById(R.id.tvDetayYonetmen);
        tvDetayTarih = findViewById(R.id.tvDetayTarih);
        tvDetayYapimci = findViewById(R.id.tvDetayYapimci);
        tvFilmadi = findViewById(R.id.tvFilmadi);
        ivDetayAfis = findViewById(R.id.ivDetayAfis);

        Film film = (Film) getIntent().getSerializableExtra("film");
        oyuncular = film.getOyuncular();
        adapter = new OyuncuAdapter(oyuncular);


        //RecyclerView verileri yatay olarak yan yana gelsin.
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

        recyclerView.setLayoutManager(layoutManager);


        recyclerView.setAdapter(adapter);


        tvFilmadi.setText(film.getAd());
        tvDetayYapimci.setText(film.getYapimci());
        tvDetayYonetmen.setText(film.getYonetmen());
        tvDetayTuru.setText(film.getTuru());
        tvDetayTarih.setText(film.getVizyonaGirisTarihi());
        tvDetaySure.setText(""+film.getSure());
        Glide.with(getApplicationContext()).load(film.getAfis()).into(ivDetayAfis);




    }
}
