package com.serifgungor.recyclerview_listegorunumu.Holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.recyclerview_listegorunumu.R;

public class ItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView tvAd,tvTur,tvVizyonaGirisTarihi,tvYonetmen,tvYapimci,tvSuresi;
    public ImageView ivAfis;

    public ItemHolder(final View view){
        super(view);
        ivAfis = view.findViewById(R.id.ivAfis);
        tvAd = view.findViewById(R.id.tvAd);
        tvTur = view.findViewById(R.id.tvTur);
        tvVizyonaGirisTarihi = view.findViewById(R.id.tvVizyonaGirisTarihi);
        tvYapimci = view.findViewById(R.id.tvYapimci);
        tvYonetmen = view.findViewById(R.id.tvYonetmen);
        tvSuresi = view.findViewById(R.id.tvSure);
        view.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

    }
}
