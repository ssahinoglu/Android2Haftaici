package com.serifgungor.recyclerview_listegorunumu.Adapter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_listegorunumu.Activity.DetayActivity;
import com.serifgungor.recyclerview_listegorunumu.Holder.ItemHolder;
import com.serifgungor.recyclerview_listegorunumu.Model.Film;
import com.serifgungor.recyclerview_listegorunumu.R;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemHolder>{

    private List<Film> filmList;

    public ItemAdapter(List<Film> films){
        this.filmList = films;
        //Dolu constructor
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Satır görüntüsü layout'unu üreten metot.
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.film_satiri,null);
        return new ItemHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemHolder holder, final int position) {
        // ItemHolder içerisinde tanımlanan nesnelerin olaylarının tanımlandığı kısımdır.
        Film film = filmList.get(position);
        holder.tvAd.setText(film.getAd());
        holder.tvTur.setText(film.getTuru());
        holder.tvSuresi.setText(""+film.getSure());
        holder.tvYonetmen.setText(film.getYonetmen());
        holder.tvYapimci.setText(film.getYapimci());
        holder.tvVizyonaGirisTarihi.setText(""+film.getVizyonaGirisTarihi());

        Glide
                .with(holder.itemView.getContext())
                .load(film.getAfis())
                .into(holder.ivAfis);
        //Glide kütüphanesi sayesinde .jpg yada png uzantılı bir resmi url'den çağırabiliriz.
        //Glide cache işlemi yaparak resimleri daha hızlı açmamızı sağlar.

        //Satıra tıklama olayı
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        v.getContext(),
                        DetayActivity.class
                );
                intent.putExtra("film",filmList.get(position));
                v.getContext().startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        //eleman sayısını döner
        return filmList.size();
    }
}
