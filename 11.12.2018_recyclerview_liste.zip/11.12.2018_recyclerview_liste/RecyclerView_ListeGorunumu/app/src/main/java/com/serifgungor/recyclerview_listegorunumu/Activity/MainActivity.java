package com.serifgungor.recyclerview_listegorunumu.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.serifgungor.recyclerview_listegorunumu.Adapter.ItemAdapter;
import com.serifgungor.recyclerview_listegorunumu.Model.Film;
import com.serifgungor.recyclerview_listegorunumu.Model.Oyuncu;
import com.serifgungor.recyclerview_listegorunumu.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ItemAdapter adapter;
    List<Film> filmList;
    RecyclerView.LayoutManager layoutManager;

    //List,Set,Map

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        filmList = new ArrayList<>();
        listele();

        recyclerView = findViewById(R.id.recyclerView);
        adapter = new ItemAdapter(filmList);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }

    public void listele(){
        /*
            private int filmId;
    private int puan;
    private String vizyonaGirisTarihi;
    private String afis;
    private String konusu;
    private String turu;
    private String ad;
    private int sure;
    private String ulke;
    private ArrayList<Oyuncu> oyuncular;
    private String yapimci;
    private String yonetmen;

         */

        /*
        private int id;
    private String adsoyad;
    private int yas;
    private String resim;
         */

        ArrayList<Oyuncu> oyuncular = new ArrayList<>();
        oyuncular.add(
                new Oyuncu(
                       1,
                       "Ad Soyad",
                       30,
                       "resim"
                )
        );

        filmList.add(
                new Film(
                        1,
                        5,
                        "11.12.2018",
                        "https://lh3.googleusercontent.com/35MxG7dc4CSkI4NPFXgOvCey3iN_sBb0oNuX6LN9eid4d3rjfXzc5qcMWcVVBoHiv3TY=w720-h310-rw",
                        "Konusu",
                        "Türü",
                        "Ad",
                        120,
                        "Türkiye",
                        oyuncular,
                        "Yapımcı",
                        "Yönetmen"

                )
        );


        filmList.add(
                new Film(
                        1,
                        5,
                        "11.12.2018",
                        "http://tr.web.img2.acsta.net/c_150_200/pictures/18/11/09/12/02/4510487.jpg",
                        "Konusu",
                        "Dram, Biyografik",
                        "Şampiyon",
                        120,
                        "Türkiye",
                        oyuncular,
                        "Yapımcı",
                        "Ahmet Katıksız"

                )
        );
    }
}
