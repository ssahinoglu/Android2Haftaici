package com.serifgungor.retrofitkullanimi.Interface;

import com.serifgungor.retrofitkullanimi.Model.MoviesResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;


public interface ApiInterface {
    @GET("restapi/top_rated.php") //movie/top_rated
    Call<MoviesResponse> getTopRatedMovies(@Query("api_key") String apiKey);

    @GET("restapi/movie_id.php") //movie/{id}
    Call<MoviesResponse> getMovieDetails(@Path("id") int id, @Query("api_key") String apiKey);
}