package com.serifgungor.instagramuidesign.Activity;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.instagramuidesign.R;

public class LoginActivity extends AppCompatActivity {

    TextView textView;
    Typeface typeface;

    EditText etEmail, etSifre;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getSupportActionBar().hide();

        typeface = Typeface.createFromAsset(getAssets(), "fonts/Billabong.ttf");
        textView = (TextView) findViewById(R.id.textView);
        textView.setTypeface(typeface);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etSifre = (EditText) findViewById(R.id.etSifre);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etEmail.getText().toString();
                String sifre = etSifre.getText().toString();

                if("root".equals(email) && "1234".equals(sifre)){
                    startActivity(new Intent(LoginActivity.this,MainActivity.class));
                }else{
                    Toast.makeText(getApplicationContext(),"Hatalı giriş",Toast.LENGTH_LONG).show();
                }

            }
        });

    }
}
