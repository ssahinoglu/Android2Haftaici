package com.serifgungor.instagramuidesign.Holders;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.serifgungor.instagramuidesign.R;

/**
 * Created by Lab08-ogretmen on 3.04.2018.
 */

public class GridView_RecyclerViewHolders extends RecyclerView.ViewHolder {
    Context context = null;
    public ImageView imgPhoto;

    public GridView_RecyclerViewHolders(final View itemView) {
        super(itemView);
        context = itemView.getContext();
        imgPhoto = (ImageView)itemView.findViewById(R.id.gridviewProfilePhoto);
        imgPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(
                        itemView.getContext(),"Resme tıklandı",
                        Toast.LENGTH_LONG
                        ).show();
            }
        });
    }
}
