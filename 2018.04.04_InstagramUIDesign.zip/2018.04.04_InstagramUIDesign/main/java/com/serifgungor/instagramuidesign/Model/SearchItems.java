package com.serifgungor.instagramuidesign.Model;

import java.util.ArrayList;

/**
 * Created by Lab08-ogretmen on 4.04.2018.
 */

public class SearchItems {
    private ArrayList<String> itemsUrl;
    private String  videoUrl;

    public SearchItems() {
    }

    public SearchItems(ArrayList<String> itemsUrl, String videoUrl) {
        this.itemsUrl = itemsUrl;
        this.videoUrl = videoUrl;
    }

    public ArrayList<String> getItemsUrl() {
        return itemsUrl;
    }

    public void setItemsUrl(ArrayList<String> itemsUrl) {
        this.itemsUrl = itemsUrl;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
