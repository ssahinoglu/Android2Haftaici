package com.serifgungor.instagramuidesign.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.serifgungor.instagramuidesign.Holders.GridView_RecyclerViewHolders;
import com.serifgungor.instagramuidesign.Model.ProfilePhotoGridModel;
import com.serifgungor.instagramuidesign.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Lab08-ogretmen on 3.04.2018.
 */

public class GridView_RecyclerViewPhotoAdapter
        extends RecyclerView.Adapter<GridView_RecyclerViewHolders> {

    private ArrayList<ProfilePhotoGridModel> arrayList;
    private Context context;
    private LayoutInflater layoutInflater;

    public GridView_RecyclerViewPhotoAdapter
            (Context context,ArrayList<ProfilePhotoGridModel> arrayList){
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public GridView_RecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.gridview_photo_profile,null);
        GridView_RecyclerViewHolders holder = new GridView_RecyclerViewHolders(layoutView);
        return holder;

    }

    @Override
    public void onBindViewHolder(GridView_RecyclerViewHolders holder, int position) {
        Picasso.with(context).load(arrayList.get(position).getPhotoUrl())
                .into(holder.imgPhoto);
    }

    @Override
    public long getItemId(int position) {
       return arrayList.get(position).getId();
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }
}
