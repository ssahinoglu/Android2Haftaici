package com.serifgungor.instagramuidesign.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.instagramuidesign.Model.UserShare;
import com.serifgungor.instagramuidesign.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Lab08-ogretmen on 27.03.2018.
 */

public class ListViewAdapter extends BaseAdapter {

    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<UserShare> liste;

    public ListViewAdapter(Context context,ArrayList<UserShare> liste){
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.liste = liste;
    }

    @Override
    public int getCount() {
        return liste.size();
    }

    @Override
    public UserShare getItem(int position) {
        return liste.get(position);
    }

    @Override
    public long getItemId(int position) {
        return liste.get(position).getUser_share_id();
    }


    ImageView iconFavori,iconPaylas,iconMesaj,ivProfilResim,ivPaylasimResmi;
    TextView tvUsername,tvZaman,tvPaylasimYazisi,tvKonum,tvBegeniSayisi;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.listview_home,parent,false);

/*
        iconFavori = (ImageView)v.findViewById(R.id.icon_like_listview);
        iconPaylas = (ImageView)v.findViewById(R.id.icon_share_listview);
        iconMesaj = (ImageView)v.findViewById(R.id.icon_comment_listview);
        */
        ivProfilResim = (ImageView)v.findViewById(R.id.ivProfilePhoto_ListView);
        ivPaylasimResmi = (ImageView)v.findViewById(R.id.ivSharePhoto_listView);
        tvUsername = (TextView)v.findViewById(R.id.tvUsername_ListView);
        tvKonum = (TextView)v.findViewById(R.id.tvLocation_ListView);
        tvZaman = (TextView)v.findViewById(R.id.tvShareTime_listView);
        tvPaylasimYazisi = (TextView)v.findViewById(R.id.tvShareText_listView);
        tvBegeniSayisi = (TextView)v.findViewById(R.id.tvLike_count_listview);

        tvBegeniSayisi.setText(""+liste.get(position).getUser_share_like_count()+" beğeni");
        tvPaylasimYazisi.setText(liste.get(position).getUser_share_content());
        tvZaman.setText(liste.get(position).getUser_share_time());
        tvKonum.setText(liste.get(position).getUser_share_location_name());
        tvUsername.setText(liste.get(position).getUser_name());
        Picasso.with(context).load(liste.get(position).getUser_photo_url()).into(ivProfilResim);
        Picasso.with(context).load(liste.get(position).getUser_share_photo_url()).into(ivPaylasimResmi);
        // Resimleri web sayfası üzerinden çeker.



        return v;
    }
}
