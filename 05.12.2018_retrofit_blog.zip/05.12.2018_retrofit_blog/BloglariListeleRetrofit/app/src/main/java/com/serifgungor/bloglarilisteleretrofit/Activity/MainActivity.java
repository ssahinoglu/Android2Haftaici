package com.serifgungor.bloglarilisteleretrofit.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.serifgungor.bloglarilisteleretrofit.Adapter.ListViewAdapter;
import com.serifgungor.bloglarilisteleretrofit.Helper.ApiClient;
import com.serifgungor.bloglarilisteleretrofit.Interface.ApiInterface;
import com.serifgungor.bloglarilisteleretrofit.Model.Blog;
import com.serifgungor.bloglarilisteleretrofit.Model.BlogResponse;
import com.serifgungor.bloglarilisteleretrofit.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ListViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        ApiInterface apiService =ApiClient.getClient().create(ApiInterface.class);

        Call<BlogResponse> call = apiService.getBloglar("");
        call.enqueue(new Callback<BlogResponse>() {
            @Override
            public void onResponse(Call<BlogResponse> call, Response<BlogResponse> response) {
                List<Blog> bloglar = response.body().getGetBlogs();

                adapter = new ListViewAdapter(getApplicationContext(),bloglar);
                listView.setAdapter(adapter);

            }

            @Override
            public void onFailure(Call<BlogResponse> call, Throwable t) {

            }
        });





    }
}
