package com.serifgungor.bloglarilisteleretrofit.Interface;

import com.serifgungor.bloglarilisteleretrofit.Model.BlogResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("content/api/post/blogs.php")
    Call<BlogResponse> getBloglar(@Query("api_key") String apiKey);


}
