package com.serifgungor.bloglarilisteleretrofit.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.bloglarilisteleretrofit.Model.Blog;
import com.serifgungor.bloglarilisteleretrofit.R;

import java.util.List;

public class ListViewAdapter extends BaseAdapter {

    List<Blog> blogs;
    Context context;
    LayoutInflater layoutInflater;

    public ListViewAdapter(){}

    public ListViewAdapter(Context context, List<Blog> bloglar){
        this.blogs = bloglar;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return blogs.size();
    }

    @Override
    public Object getItem(int position) {
        return blogs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.listview_row,null);

        ImageView ivPhoto = v.findViewById(R.id.ivBlogPhoto);
        TextView tvTitle = v.findViewById(R.id.tvBlogTitle);
        TextView tvShareTime = v.findViewById(R.id.tvShareTime);
        TextView tvViewCount = v.findViewById(R.id.tvViewCount);

        tvTitle.setText(blogs.get(position).getBlog_seo_title());
        tvViewCount.setText(blogs.get(position).getBlog_do_viewcount());
        tvShareTime.setText(blogs.get(position).getSharetime());
        Glide.with(v.getContext()).load("https://serifgungor.com/"+blogs.get(position).getImage()).into(ivPhoto);

        return v;
    }
}
