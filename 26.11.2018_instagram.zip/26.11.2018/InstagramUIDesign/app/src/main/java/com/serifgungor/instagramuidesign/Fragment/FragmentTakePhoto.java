package com.serifgungor.instagramuidesign.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.serifgungor.instagramuidesign.R;

/**
 * Created by Lab08-ogretmen on 26.03.2018.
 */

public class FragmentTakePhoto extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_layout_takephoto,container,false);

        return view;
    }
}
