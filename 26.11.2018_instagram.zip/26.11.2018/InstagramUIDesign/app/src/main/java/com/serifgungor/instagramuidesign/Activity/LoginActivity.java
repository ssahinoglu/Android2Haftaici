package com.serifgungor.instagramuidesign.Activity;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.instagramuidesign.R;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    TextView textView;
    Typeface typeface;

    EditText etEmail, etSifre;
    Button btnLogin,btnRegister;

    RequestQueue queue;

    public void login(final String email,final String pass){
        StringRequest istek = new StringRequest(
                Request.Method.POST,
                "http://10.1.9.30/instagram/login.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if("100".equals(response)){
                            startActivity(new Intent(LoginActivity.this,MainActivity.class));
                        }else if("101".equals(response)){
                            Toast.makeText(getApplicationContext(),"Hatalı giriş",Toast.LENGTH_LONG).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("email",email);
                map.put("password",pass);
                return map;
            }
        };
        queue.add(istek);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        queue = Volley.newRequestQueue(getApplicationContext());


        getSupportActionBar().hide();

        typeface = Typeface.createFromAsset(getAssets(), "fonts/Billabong.ttf");
        textView = (TextView) findViewById(R.id.textView);
        textView.setTypeface(typeface);

        btnRegister = findViewById(R.id.btnRegister);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etSifre = (EditText) findViewById(R.id.etSifre);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etEmail.getText().toString();
                String sifre = etSifre.getText().toString();
                login(email,sifre);

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
}
