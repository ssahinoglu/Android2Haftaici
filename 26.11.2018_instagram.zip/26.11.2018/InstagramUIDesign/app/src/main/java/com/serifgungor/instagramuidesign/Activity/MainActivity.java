package com.serifgungor.instagramuidesign.Activity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.serifgungor.instagramuidesign.Fragment.FragmentFavories;
import com.serifgungor.instagramuidesign.Fragment.FragmentHome;
import com.serifgungor.instagramuidesign.Fragment.FragmentProfile;
import com.serifgungor.instagramuidesign.Fragment.FragmentSearch;
import com.serifgungor.instagramuidesign.Fragment.FragmentTakePhoto;
import com.serifgungor.instagramuidesign.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView ivHome,ivSearch,ivTakePhoto,ivLikes,ivProfile;
    int tabIndex = 0;


    public void setDefaultImage(){
        ivHome.setImageResource(R.drawable.dock_home_gri);
        ivSearch.setImageResource(R.drawable.dock_search_gri);
        ivTakePhoto.setImageResource(R.drawable.dock_camera_gri);
        ivLikes.setImageResource(R.drawable.dock_news_gri);
        ivProfile.setImageResource(R.drawable.dock_profile_gri);
    }

    public void changeFragment(int fragmentTabIndex){
        Fragment fragment = null;
        switch (fragmentTabIndex){
            case 0:
                fragment = new FragmentHome();
                break;
            case 1:
                fragment = new FragmentSearch();
                break;
            case 2:
                fragment = new FragmentTakePhoto();
                break;
            case 3:
                fragment = new FragmentFavories();
                break;
            case 4:
                fragment = new FragmentProfile();
                break;
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,fragment);
        fragmentTransaction.commit();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ivHome:
                tabIndex = 0;
                setDefaultImage();
                ivHome.setImageResource(R.drawable.dock_home_whiteout);
                break;
            case R.id.ivSearch:
                tabIndex = 1;
                setDefaultImage();
                ivSearch.setImageResource(R.drawable.dock_search_whiteout);
                break;
            case R.id.ivTakePhoto:
                setDefaultImage();
                ivTakePhoto.setImageResource(R.drawable.dock_camera_whiteout);
                tabIndex = 2;
                break;
            case R.id.ivFavories:
                tabIndex = 3;
                setDefaultImage();
                ivLikes.setImageResource(R.drawable.dock_news_whiteout);
                break;
            case R.id.ivProfile:
                tabIndex = 4;
                setDefaultImage();
                ivProfile.setImageResource(R.drawable.dock_profile_whiteout);
                break;
        }
        changeFragment(tabIndex);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.getSupportActionBar().hide();

        ivHome = (ImageView)findViewById(R.id.ivHome);
        ivSearch = (ImageView)findViewById(R.id.ivSearch);
        ivTakePhoto = (ImageView)findViewById(R.id.ivTakePhoto);
        ivLikes = (ImageView)findViewById(R.id.ivFavories);
        ivProfile = (ImageView)findViewById(R.id.ivProfile);
        ivHome.setOnClickListener(this);
        ivProfile.setOnClickListener(this);
        ivLikes.setOnClickListener(this);
        ivTakePhoto.setOnClickListener(this);
        ivSearch.setOnClickListener(this);
        ivHome.setImageResource(R.drawable.dock_home_whiteout);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,new FragmentHome());
        fragmentTransaction.commit();

    }


}
