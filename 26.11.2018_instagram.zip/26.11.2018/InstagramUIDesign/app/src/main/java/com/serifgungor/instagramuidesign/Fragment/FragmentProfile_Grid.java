package com.serifgungor.instagramuidesign.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.serifgungor.instagramuidesign.Adapter.GridView_RecyclerViewPhotoAdapter;
import com.serifgungor.instagramuidesign.Model.ProfilePhotoGridModel;
import com.serifgungor.instagramuidesign.R;

import java.util.ArrayList;

/**
 * Created by Lab08-ogretmen on 3.04.2018.
 */

public class FragmentProfile_Grid extends Fragment {
    RecyclerView recyclerViewPhotos;
    GridLayoutManager lLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.fragment_profile_grid,null);

        lLayout = new GridLayoutManager(getContext().getApplicationContext(),3);

        recyclerViewPhotos =
                (RecyclerView)v.findViewById(R.id.recyclerViewPhotos);

        recyclerViewPhotos.setHasFixedSize(true);
        recyclerViewPhotos.setLayoutManager(lLayout);

        GridView_RecyclerViewPhotoAdapter adapter =
                new GridView_RecyclerViewPhotoAdapter(getContext(),getAllItemList());
        recyclerViewPhotos.setAdapter(adapter);
        recyclerViewPhotos.setNestedScrollingEnabled(false);

       return v;
    }

    private ArrayList<ProfilePhotoGridModel> getAllItemList(){
        ArrayList<ProfilePhotoGridModel> arrayList = new ArrayList<>();

        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-otp1-1.cdninstagram.com/vp/24500e4495de819cbecd88333683db4b/5B645835/t51.2885-15/e35/25017046_173800006704975_5320379549530193920_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );

        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-otp1-1.cdninstagram.com/vp/24500e4495de819cbecd88333683db4b/5B645835/t51.2885-15/e35/25017046_173800006704975_5320379549530193920_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );
        arrayList.add(
                new ProfilePhotoGridModel(
                        1, "https://scontent-mxp1-1.cdninstagram.com/vp/26b96426d595e8f7df628e19bb1de07d/5B2C0CE2/t51.2885-15/e35/c125.0.330.330/23347398_1494101354030996_3813232799029133312_n.jpg", "Tarih"
                )
        );

        return arrayList;
    }


}
