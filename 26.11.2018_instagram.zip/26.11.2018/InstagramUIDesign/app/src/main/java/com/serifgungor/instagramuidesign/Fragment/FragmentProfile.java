package com.serifgungor.instagramuidesign.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.instagramuidesign.R;
import com.squareup.picasso.Picasso;

/**
 * Created by Lab08-ogretmen on 26.03.2018.
 */

public class FragmentProfile extends Fragment {

    public void changeTab(int refId,Fragment fragment){
        getFragmentManager()
                .beginTransaction()
                .replace(refId,fragment)
                .commit();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_layout_profile,container,false);

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        ImageView ivProfileMenu =
                (ImageView)view.findViewById(R.id.btnProfileMenu);
        ImageView ivProfilePhoto =
                (ImageView)view.findViewById(R.id.ivProfilePhoto);
        TextView tvProfilePostCount =
                (TextView)view.findViewById(R.id.tvProfilePostCount);
        TextView tvProfileFollowCount =
                (TextView)view.findViewById(R.id.tvProfileFollowCount);
        TextView tvProfileFollowerCount =
                (TextView)view.findViewById(R.id.tvProfileFollowerCount);
        TextView tvUserName =
                (TextView)view.findViewById(R.id.tvProfileUsername);
        TextView tvDescription =
                (TextView)view.findViewById(R.id.tvProfileDescription);
        TextView tvUserWebsite =
                (TextView)view.findViewById(R.id.tvProfileWebsite);
        TextView tvProfileTitle =
                (TextView)view.findViewById(R.id.tvProfileTitle);
        Button btnUpdateProfile =
                (Button)view.findViewById(R.id.btnProfileUpdate);


        tvProfileFollowCount.setText("100");
        tvProfileFollowerCount.setText("70");
        tvProfilePostCount.setText("20");
        tvProfileTitle.setText("serifgungor34");
        tvUserName.setText("serifgungor34");
        tvUserWebsite.setText("http://serifgungor.com");
        tvDescription.setText("Hi, I'm new here !");
        Picasso.with(getContext())
                .load("https://scontent-otp1-1.cdninstagram.com/vp/24500e4495de819cbecd88333683db4b/5B645835/t51.2885-15/e35/25017046_173800006704975_5320379549530193920_n.jpg")
                .into(ivProfilePhoto);
        Linkify.addLinks(tvUserWebsite,Linkify.WEB_URLS);

        ImageView ivProfilePhotosSaved =
                (ImageView)view.findViewById(R.id.ivProfilePhotosSaved);
        ImageView ivProfilePhotosLabel =
                (ImageView)view.findViewById(R.id.ivProfilePhotosLabel);
        ImageView ivProfilePhotosList =
                (ImageView)view.findViewById(R.id.ivProfilePhotosList);
        ImageView ivProfilePhotosGrid =
                (ImageView)view.findViewById(R.id.ivProfilePhotosGrid);

        ivProfilePhotosGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTab(R.id.frameProfile,new FragmentProfile_Grid());
            }
        });

        ivProfilePhotosList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTab(R.id.frameProfile,new FragmentProfiile_List());
            }
        });

        ivProfilePhotosLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTab(R.id.frameProfile,new FragmentProfile_Label());
            }
        });

        ivProfilePhotosSaved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTab(R.id.frameProfile,new FragmentProfile_Saved());
            }
        });


        getFragmentManager()
                .beginTransaction()
                .replace(R.id.frameProfile,new FragmentProfile_Grid())
                .commit();

    }
}
