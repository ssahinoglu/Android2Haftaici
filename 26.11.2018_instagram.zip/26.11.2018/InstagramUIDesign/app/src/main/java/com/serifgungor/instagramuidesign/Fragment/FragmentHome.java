package com.serifgungor.instagramuidesign.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.serifgungor.instagramuidesign.Adapter.ListViewAdapter;
import com.serifgungor.instagramuidesign.Model.UserShare;
import com.serifgungor.instagramuidesign.R;

import java.util.ArrayList;

/**
 * Created by Lab08-ogretmen on 26.03.2018.
 */

public class FragmentHome extends Fragment {

    ListView listView;
    ArrayList<UserShare> liste = new ArrayList<>();

    private void init() {


        liste.add(
                new UserShare(
                        1,
                        1,
                        "https://scontent-sof1-1.cdninstagram.com/vp/e44621ac6e0fa20dde7652d2431ad0ed/5B58D62F/t51.2885-19/s150x150/29738612_164502504253972_2938372867349282816_n.jpg",
                        50,
                        "Bu benim ilk paylaşımım !",
                        "5 dakika önce",
                        "https://scontent-vie1-1.cdninstagram.com/vp/38b9695ca7d506fb19c85fc1ce633013/5B6E6885/t51.2885-15/e35/29416894_250604845481057_7910167957693530112_n.jpg",
                        "Fatih/İstanbul",
                        "Şerif Güngör"
                )
        );
        liste.add(
                new UserShare(
                        1,
                        1,
                        "https://scontent-vie1-1.cdninstagram.com/vp/295f9e76d3c26fdf613d7856e7b43348/5B4F495B/t51.2885-19/s150x150/14719833_310540259320655_1605122788543168512_a.jpg",
                        50,
                        "Bu benim ilk paylaşımım !",
                        "5 dakika önce",
                        "https://scontent-vie1-1.cdninstagram.com/vp/38b9695ca7d506fb19c85fc1ce633013/5B6E6885/t51.2885-15/e35/29416894_250604845481057_7910167957693530112_n.jpg",
                        "Fatih/İstanbul",
                        "Şerif Güngör"
                )
        );
        liste.add(
                new UserShare(
                        1,
                        1,
                        "https://scontent-vie1-1.cdninstagram.com/vp/295f9e76d3c26fdf613d7856e7b43348/5B4F495B/t51.2885-19/s150x150/14719833_310540259320655_1605122788543168512_a.jpg",
                        50,
                        "Bu benim ilk paylaşımım !",
                        "5 dakika önce",
                        "https://scontent-vie1-1.cdninstagram.com/vp/38b9695ca7d506fb19c85fc1ce633013/5B6E6885/t51.2885-15/e35/29416894_250604845481057_7910167957693530112_n.jpg",
                        "Fatih/İstanbul",
                        "Şerif Güngör"
                )
        );
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_layout_home, container, false);

        init(); // ArrayList'e elemanları ekledik.
        listView = (ListView) view.findViewById(R.id.listViewHomeShare);
        ListViewAdapter adapter = new ListViewAdapter(getContext(), liste);
        listView.setAdapter(adapter);

        return view;
    }
}
