package com.serifgungor.instagramuidesign.Config;

public class VolleyUrls {
    private static String domain="http://192.168.2.109/";
    public static String LOGIN_URL = domain+"instagram/login.php";
    public static String REGISTER_URL = domain+"instagram/register.php";
    public static String UPLOAD_IMAGE_URL = domain+"instagram/image_upload.php";
    public static String USER_SHARE_URL = domain+"instagram/user_share.php";
}
