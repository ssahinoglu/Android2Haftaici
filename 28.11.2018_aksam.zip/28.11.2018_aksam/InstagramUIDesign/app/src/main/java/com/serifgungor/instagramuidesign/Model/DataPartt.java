package com.serifgungor.instagramuidesign.Model;

public class DataPartt {
    private String fileName;
    private byte[] content;
    private String type;

    public DataPartt() {
    }

    public DataPartt(String name, byte[] data) {
        fileName = name;
        content = data;
    }

    public String getFileName() {
        return fileName;
    }

    public byte[] getContent() {
        return content;
    }

    public String getType() {
        return type;
    }

}
