package com.serifgungor.instagramuidesign.Adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;

import com.serifgungor.instagramuidesign.Holders.SearchView_RecyclerViewHolders;
import com.serifgungor.instagramuidesign.Model.SearchItems;
import com.serifgungor.instagramuidesign.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Lab08-ogretmen on 4.04.2018.
 */

public class SerchView_RecyclerviewMediaAdapter extends RecyclerView.Adapter
        <SearchView_RecyclerViewHolders> {
    private ArrayList<SearchItems> arrayList;
    private Context context;
    private LayoutInflater layoutInflater;

    public SerchView_RecyclerviewMediaAdapter
            (Context context, ArrayList<SearchItems> arrayList) {
        this.arrayList = arrayList;
        this.context = context;
    }


    @Override
    public SearchView_RecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.searchview_media, null);
        SearchView_RecyclerViewHolders holder
                = new SearchView_RecyclerViewHolders(layoutView);
        return holder;
    }

    @Override
    public void onBindViewHolder(SearchView_RecyclerViewHolders holder, int position) {
        //Glide
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(0)
                )
                .into(holder.iv1);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(1)
                )
                .into(holder.iv2);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(2)
                )
                .into(holder.iv3);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(3)
                )
                .into(holder.iv4);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(4)
                )
                .into(holder.iv5);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(5)
                )
                .into(holder.iv6);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(6)
                )
                .into(holder.iv7);
        Picasso
                .with(context)
                .load(
                        arrayList.get(position).getItemsUrl().get(7)
                )
                .into(holder.iv8);

        String videoPath = arrayList.get(position).getVideoUrl();
        Uri uri = Uri.parse(videoPath);

        MediaController mediaController = new MediaController(context);
        holder.vv1.setMediaController(mediaController);
        holder.vv1.setVideoURI(uri);

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }
}
