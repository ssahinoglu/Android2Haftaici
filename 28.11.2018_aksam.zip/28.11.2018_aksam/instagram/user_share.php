<?php
require_once("class.database_sqlite.php");

global $db2;
$json = array();
$array = getPaylasimlar();


for($i=0; $i<count($array); $i++){
	$itemObject = new stdClass();
	$itemObject->user_share_id = $array[$i]['user_share_id'];
	$itemObject->user_id = $array[$i]['user_id'];
	$itemObject->user_photo_url = $array[$i]['user_photo_url'];
	$itemObject->user_share_like_count = $array[$i]['user_share_like_count'];
	$itemObject->user_share_content = $array[$i]['user_share_content'];
	$itemObject->user_share_time = $array[$i]['user_share_time'];
	$itemObject->user_share_photo_url = $array[$i]['user_share_photo_url'];
	$itemObject->user_share_location_name = $array[$i]['user_share_location_name'];
	array_push($json, $itemObject);
}


	$response = array('usershare' => $json);
	echo json_encode($response, JSON_PRETTY_PRINT);


//getFruit($db2);
header('Content-Type: application/json');

?>