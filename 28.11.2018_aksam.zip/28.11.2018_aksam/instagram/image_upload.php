<?php 
 
 //first confirming that we have the image and tags in the request parameter
 if($_FILES['pic']['name']){

 move_uploaded_file($_FILES['pic']['tmp_name'], 'uploads/'.$_FILES['pic']['name']);
	 echo 'File uploaded successfully';
 }
 ?>