package com.serifgungor.recyclerview_staggeredgridview.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

import com.serifgungor.recyclerview_staggeredgridview.Adapter.Photo_Adapter;
import com.serifgungor.recyclerview_staggeredgridview.Model.Photo;
import com.serifgungor.recyclerview_staggeredgridview.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Photo_Adapter adapter;
    List<Photo> photos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        photos = new ArrayList<>();
        /*
        int id, String photoUrl, String photoTitle, String userPhotoUrl, String userName, String userDescription
         */
        photos.add(
                new Photo(1,"https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","Penguen","https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","username","açıklama")
        );
        photos.add(
                new Photo(1,"https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","Penguen","https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","username","açıklama")
        );
        photos.add(
                new Photo(1,"https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","Penguen","https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","username","açıklama")
        );
        photos.add(
                new Photo(1,"https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","Penguen","https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60","username","açıklama")
        );


        recyclerView = findViewById(R.id.recyclerView);
        adapter = new Photo_Adapter(photos);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        /*
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2,LinearLayoutManager.VERTICAL));
         */
        recyclerView.setAdapter(adapter);
    }
}