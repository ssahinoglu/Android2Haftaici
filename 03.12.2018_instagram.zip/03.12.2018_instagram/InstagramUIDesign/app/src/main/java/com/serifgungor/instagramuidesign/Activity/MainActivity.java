package com.serifgungor.instagramuidesign.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.serifgungor.instagramuidesign.Config.VolleyUrls;
import com.serifgungor.instagramuidesign.Fragment.FragmentFavories;
import com.serifgungor.instagramuidesign.Fragment.FragmentHome;
import com.serifgungor.instagramuidesign.Fragment.FragmentProfile;
import com.serifgungor.instagramuidesign.Fragment.FragmentSearch;
import com.serifgungor.instagramuidesign.Fragment.FragmentTakePhoto;
import com.serifgungor.instagramuidesign.Helper.VolleyMultipartRequest;
import com.serifgungor.instagramuidesign.Model.DataPartt;
import com.serifgungor.instagramuidesign.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView ivHome,ivSearch,ivTakePhoto,ivLikes,ivProfile;
    int tabIndex = 0;

    SharedPreferences sharedPreferences;

    public void paylasimDialog(final Bitmap bitmap){
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.custom_share_dialog);
        final EditText etPaylasimYazisi = dialog.findViewById(R.id.etShareText);
        Button btn = dialog.findViewById(R.id.btnSharePhoto);
        ImageView ivResim = dialog.findViewById(R.id.ivSharePhotoPreview);

        try {
            ivResim.setImageBitmap(bitmap);
        }catch (Exception e){

        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadBitmap(bitmap,etPaylasimYazisi.getText().toString(),"");
                dialog.dismiss();
            }
        });
        dialog.setCancelable(true);
        dialog.show();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            try {
                //getting bitmap object from uri
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                paylasimDialog(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    private void uploadBitmap(final Bitmap bitmap,final String shareContent,final String shareLocation) {

        //getting the tag from the edittext
        //final String tags = editTextTags.getText().toString().trim();

        //our custom volley request
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(
                Request.Method.POST,
                VolleyUrls.UPLOAD_IMAGE_URL,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));
                            Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.d("LOG",new String(response.data));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            /*
             * If you want to add more parameters with the image
             * you can do it here
             * here we have only one parameter with the image
             * which is tags
             * */
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //params.put("tags", tags);
                params.put("userid",""+sharedPreferences.getInt("userid",0));
                params.put("share_content",shareContent);
                params.put("share_location",shareLocation);
                return params;
            }

            /*
             * Here we are passing image by renaming it with a unique name
             * */
            @Override
            protected Map<String, DataPartt> getByteData() {
                Map<String, DataPartt> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("pic", new DataPartt(imagename + ".png", getFileDataFromDrawable(bitmap)));
                return params;
            }
        };

        //adding the request to volley
        Volley.newRequestQueue(this).add(volleyMultipartRequest);
    }




    public void setDefaultImage(){
        ivHome.setImageResource(R.drawable.dock_home_gri);
        ivSearch.setImageResource(R.drawable.dock_search_gri);
        ivTakePhoto.setImageResource(R.drawable.dock_camera_gri);
        ivLikes.setImageResource(R.drawable.dock_news_gri);
        ivProfile.setImageResource(R.drawable.dock_profile_gri);
    }

    public void changeFragment(int fragmentTabIndex){
        Fragment fragment = null;
        switch (fragmentTabIndex){
            case 0:
                fragment = new FragmentHome();
                break;
            case 1:
                fragment = new FragmentSearch();
                break;
            case 2:
                fragment = new FragmentTakePhoto();
                break;
            case 3:
                fragment = new FragmentFavories();
                break;
            case 4:
                fragment = new FragmentProfile();
                break;
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,fragment);
        fragmentTransaction.commit();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ivHome:
                tabIndex = 0;
                setDefaultImage();
                ivHome.setImageResource(R.drawable.dock_home_whiteout);
                changeFragment(tabIndex);
                break;
            case R.id.ivSearch:
                tabIndex = 1;
                setDefaultImage();
                ivSearch.setImageResource(R.drawable.dock_search_whiteout);
                changeFragment(tabIndex);
                break;
            case R.id.ivTakePhoto:

                setDefaultImage();
                ivTakePhoto.setImageResource(R.drawable.dock_camera_whiteout);
                tabIndex = 2;
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, 100);

                break;
            case R.id.ivFavories:
                tabIndex = 3;
                setDefaultImage();
                ivLikes.setImageResource(R.drawable.dock_news_whiteout);
                changeFragment(tabIndex);
                break;
            case R.id.ivProfile:
                tabIndex = 4;
                setDefaultImage();
                ivProfile.setImageResource(R.drawable.dock_profile_whiteout);
                changeFragment(tabIndex);
                break;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        this.getSupportActionBar().hide();

        ivHome = (ImageView)findViewById(R.id.ivHome);
        ivSearch = (ImageView)findViewById(R.id.ivSearch);
        ivTakePhoto = (ImageView)findViewById(R.id.ivTakePhoto);
        ivLikes = (ImageView)findViewById(R.id.ivFavories);
        ivProfile = (ImageView)findViewById(R.id.ivProfile);
        ivHome.setOnClickListener(this);
        ivProfile.setOnClickListener(this);
        ivLikes.setOnClickListener(this);
        ivTakePhoto.setOnClickListener(this);
        ivSearch.setOnClickListener(this);
        ivHome.setImageResource(R.drawable.dock_home_whiteout);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,new FragmentHome());
        fragmentTransaction.commit();

    }


}
