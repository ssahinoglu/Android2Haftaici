package com.serifgungor.instagramuidesign.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.serifgungor.instagramuidesign.Adapter.SerchView_RecyclerviewMediaAdapter;
import com.serifgungor.instagramuidesign.Model.SearchItems;
import com.serifgungor.instagramuidesign.R;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Lab08-ogretmen on 26.03.2018.
 */

public class FragmentSearch extends Fragment {
    RecyclerView recyclerViewSearch;
    GridLayoutManager lLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_layout_search,container,false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        lLayout = new GridLayoutManager(getContext().getApplicationContext(),1);
        EditText etSearch = (EditText)view.findViewById(R.id.etSearch);
        recyclerViewSearch = (RecyclerView)
                view.findViewById(R.id.recyclerViewSearch);
        recyclerViewSearch.setHasFixedSize(true);
        recyclerViewSearch.setLayoutManager(lLayout);

        SerchView_RecyclerviewMediaAdapter adapter =
                new SerchView_RecyclerviewMediaAdapter(getContext(), getAllItemList());

        recyclerViewSearch.setAdapter(adapter);
        recyclerViewSearch.setNestedScrollingEnabled(false);

    }

    private ArrayList<SearchItems> getAllItemList(){
        ArrayList<SearchItems> items = new ArrayList<>();

        ArrayList<String> resimUrl = new ArrayList<>();
        resimUrl.add("https://images.pexels.com/photos/920212/pexels-photo-920212.jpeg?auto=compress&cs=tinysrgb&h=350");
        resimUrl.add("https://images.pexels.com/photos/917494/pexels-photo-917494.jpeg?auto=compress&cs=tinysrgb&h=350");
        resimUrl.add("https://images.pexels.com/photos/931150/pexels-photo-931150.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260");
        resimUrl.add("https://images.pexels.com/photos/840284/pexels-photo-840284.jpeg?auto=compress&cs=tinysrgb&h=350");
        resimUrl.add("https://images.pexels.com/photos/979003/pexels-photo-979003.jpeg?auto=compress&cs=tinysrgb&h=350");
        resimUrl.add("https://images.pexels.com/photos/976916/pexels-photo-976916.jpeg?auto=compress&cs=tinysrgb&h=350");
        resimUrl.add("https://images.pexels.com/photos/36675/pexels-photo.jpg?auto=compress&cs=tinysrgb&h=350");
        resimUrl.add("https://images.pexels.com/photos/14644/pexels-photo-14644.jpeg?auto=compress&cs=tinysrgb&h=350");

        items.add(new SearchItems(resimUrl,"http://www.leanbackplayer.com/videos/360p/big_buck_bunny_640x360_2.28.mp4"));
        items.add(new SearchItems(resimUrl,"http://www.leanbackplayer.com/videos/360p/big_buck_bunny_640x360_2.28.mp4"));
        items.add(new SearchItems(resimUrl,"http://www.leanbackplayer.com/videos/360p/big_buck_bunny_640x360_2.28.mp4"));
        items.add(new SearchItems(resimUrl,"http://www.leanbackplayer.com/videos/360p/big_buck_bunny_640x360_2.28.mp4"));
        items.add(new SearchItems(resimUrl,"http://www.leanbackplayer.com/videos/360p/big_buck_bunny_640x360_2.28.mp4"));


        return items;
    }

}
