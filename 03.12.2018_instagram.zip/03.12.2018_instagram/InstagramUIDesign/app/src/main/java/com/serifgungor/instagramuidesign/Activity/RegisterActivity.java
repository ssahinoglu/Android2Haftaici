package com.serifgungor.instagramuidesign.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.instagramuidesign.Config.VolleyUrls;
import com.serifgungor.instagramuidesign.R;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText etUsername,etPass,etNameSurname,etMail;
    Button btnReg;

    RequestQueue queue;

    public void register(final String email,final String password,final String namesurname,final String username){
        StringRequest istek = new StringRequest(
                Request.Method.POST,
                VolleyUrls.REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("register",response);
                        if("ok".equals(response)){
                            Toast.makeText(getApplicationContext(),"Kayıt başarılı",Toast.LENGTH_LONG).show();
                        }else if("-1".equals(response)){
                            Toast.makeText(getApplicationContext(),"Değerler boş bırakılamaz",Toast.LENGTH_LONG).show();
                        }else if("-2".equals(response)){
                            Toast.makeText(getApplicationContext(),"Veritabanına bağlanılamadı",Toast.LENGTH_LONG).show();
                        }else if("-3".equals(response)){
                            Toast.makeText(getApplicationContext(),"Erişim reddedildi",Toast.LENGTH_LONG).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("email",email);
                map.put("password",password);
                map.put("namesurname",namesurname);
                map.put("username",username);
                return map;
            }
        };
        queue.add(istek);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        queue = Volley.newRequestQueue(getApplicationContext());

        etMail = findViewById(R.id.etRegisterEmail);
        etPass = findViewById(R.id.etRegisterPassword);
        etNameSurname = findViewById(R.id.etRegisterNameSurname);
        etUsername = findViewById(R.id.etRegisterUsername);
        btnReg = findViewById(R.id.btnSignUp);

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mail = etMail.getText().toString();
                String pass = etPass.getText().toString();
                String name = etNameSurname.getText().toString();
                String username = etUsername.getText().toString();
                register(mail,pass,name,username);
                finish();

            }
        });

    }
}
