package com.serifgungor.instagramuidesign.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.instagramuidesign.Config.VolleyUrls;
import com.serifgungor.instagramuidesign.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    TextView textView;
    Typeface typeface;

    EditText etEmail, etSifre;
    Button btnLogin,btnRegister;

    RequestQueue queue;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public void login(final String email,final String pass){
        StringRequest istek = new StringRequest(
                Request.Method.POST,
                VolleyUrls.LOGIN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if("101".equals(response)){
                            Toast.makeText(getApplicationContext(),"Hatalı giriş",Toast.LENGTH_LONG).show();
                        }else if("102".equals(response)){
                            Toast.makeText(getApplicationContext(),"Sunucu bağlantı hatası",Toast.LENGTH_LONG).show();
                        }else if("103".equals(response)){
                            Toast.makeText(getApplicationContext(),"Geçersiz istek",Toast.LENGTH_LONG).show();
                        }else{
                            // Kullanıcı adı ve şifre doğruysa
                            try {
                                JSONObject object = new JSONObject(response);
                                JSONArray jsonArray = object.optJSONArray("user");

                                JSONObject user = jsonArray.getJSONObject(0);
                                String email = user.getString("email");
                                String namesurname = user.getString("namesurname");
                                int userid = Integer.parseInt(user.getString("userid"));
                                String gender = user.getString("gender");
                                String username = user.getString("username");
                                String description = user.getString("description");
                                String profilePhoto = user.getString("profilephoto");
                                String website = user.getString("website");
                                String phoneNumber = user.getString("phonenumber");
                                String registerDate = user.getString("registerdate");
                                int verified_user = Integer.parseInt(user.getString("verified_user"));
                                int private_mode = Integer.parseInt(user.getString("private_mode"));
                                int business_mode = Integer.parseInt(user.getString("business_mode"));

                                editor.putInt("userid",userid);
                                editor.putString("username",username);
                                editor.putString("email",email);
                                editor.putString("namesurname",namesurname);
                                editor.putString("gender",gender);
                                editor.putString("description",description);
                                editor.putString("profilephoto",profilePhoto);
                                editor.putString("website",website);
                                editor.putString("phonenumber",phoneNumber);
                                editor.putString("registerdate",registerDate);
                                editor.putInt("verified_user",verified_user);
                                editor.putInt("private_mode",private_mode);
                                editor.putInt("business_mode",business_mode);
                                editor.commit();

                                startActivity(new Intent(LoginActivity.this,MainActivity.class));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }

                        /*

                        101 - KULLANICI ADI VE ŞİFRE HATALI
                        102 - SUNUCU BAĞLANTI HATASI
                        103 - İSTEK HATASI

                         */

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("email",email);
                map.put("password",pass);
                return map;
            }
        };
        queue.add(istek);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        queue = Volley.newRequestQueue(getApplicationContext());

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor = sharedPreferences.edit();


        getSupportActionBar().hide();

        typeface = Typeface.createFromAsset(getAssets(), "fonts/Billabong.ttf");
        textView = (TextView) findViewById(R.id.textView);
        textView.setTypeface(typeface);

        btnRegister = findViewById(R.id.btnRegister);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etSifre = (EditText) findViewById(R.id.etSifre);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etEmail.getText().toString();
                String sifre = etSifre.getText().toString();
                login(email,sifre);

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
}
