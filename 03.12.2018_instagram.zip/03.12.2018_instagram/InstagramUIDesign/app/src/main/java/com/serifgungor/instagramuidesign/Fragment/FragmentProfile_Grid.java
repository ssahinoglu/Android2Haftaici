package com.serifgungor.instagramuidesign.Fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.instagramuidesign.Adapter.GridView_RecyclerViewPhotoAdapter;
import com.serifgungor.instagramuidesign.Config.VolleyUrls;
import com.serifgungor.instagramuidesign.Model.ProfilePhotoGridModel;
import com.serifgungor.instagramuidesign.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lab08-ogretmen on 3.04.2018.
 */

public class FragmentProfile_Grid extends Fragment {
    RecyclerView recyclerViewPhotos;
    GridLayoutManager lLayout;
    ArrayList<ProfilePhotoGridModel> arrayList;
    SharedPreferences sharedPreferences;

    RequestQueue istekKuyrugu;

    public void getMyShares(){
        StringRequest request = new StringRequest(
                Request.Method.POST,
                VolleyUrls.MY_SHARES,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        Log.d("WEB_RESPONSE",response);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("myshare");

                            for(int i=0; i<jsonArray.length(); i++){
                                JSONObject object = jsonArray.getJSONObject(i);
                                int user_share_id = Integer.parseInt(object.getString("user_share_id"));
                                int user_id = Integer.parseInt(object.getString("user_id"));
                                String user_photo_url = object.getString("user_photo_url");
                                int user_share_like_count = Integer.parseInt(object.getString("user_share_like_count"));
                                String user_share_content = object.getString("user_share_content");
                                String user_share_time = object.getString("user_share_time");
                                String user_share_photo_url = object.getString("user_share_photo_url");
                                String user_share_location_name = object.getString("user_share_location_name");


                                arrayList.add(
                                        new ProfilePhotoGridModel(
                                                user_share_id, user_share_photo_url, user_share_time
                                        )
                                );

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }





                        GridView_RecyclerViewPhotoAdapter adapter =
                                new GridView_RecyclerViewPhotoAdapter(getContext(),arrayList);
                        recyclerViewPhotos.setAdapter(adapter);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("user_id",""+sharedPreferences.getInt("userid",0));
                return map;
            }
        };
        istekKuyrugu.add(request);
    }




    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.fragment_profile_grid,null);

       sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext());

       istekKuyrugu = Volley.newRequestQueue(v.getContext());

        lLayout = new GridLayoutManager(getContext().getApplicationContext(),3);

        recyclerViewPhotos =
                (RecyclerView)v.findViewById(R.id.recyclerViewPhotos);

        recyclerViewPhotos.setHasFixedSize(true);
        recyclerViewPhotos.setLayoutManager(lLayout);


        arrayList = new ArrayList<>();
        getMyShares();

        recyclerViewPhotos.setNestedScrollingEnabled(false);

       return v;
    }




}
