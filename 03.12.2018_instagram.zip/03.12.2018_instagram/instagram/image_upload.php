<?php 
 require_once("class.database_sqlite.php");

 $userid = $_POST['userid'];
 $share_content = $_POST['share_content'];
 $tarih = 	 date("d.m.Y H:i:s");
 $share_location = $_POST['share_location'];

 //first confirming that we have the image and tags in the request parameter
 if($_FILES['pic']['name']){


	global $db2;
	try{
		$photo_url = 'uploads/'.$_FILES['pic']['name'];
		move_uploaded_file($_FILES['pic']['tmp_name'], $photo_url);

		executeSqlite("insert into UserShare values(NULL,$userid,'https://serifgungor.com/images/my-photo.jpg','0','".$share_content."','".$tarih."','http://10.1.9.14:8081/instagram/".$photo_url."','". $share_location."')");
		
		echo "ok";

	}catch(PDOException $e){
		echo "fail";
	}

 }
 ?>