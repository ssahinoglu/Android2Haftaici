<?php
require_once("class.database_sqlite.php");


if($_SERVER['REQUEST_METHOD']=="POST"){

$email = $_POST['email'];
$password = $_POST['password'];


	//header('Content-Type: application/json');
	global $db2;
	try{
		// eğer mail adresi kayıtlıysa bunu, değilse bunu yap
		if(selectCountInTable_OptionalValues_sqlite("User","email='".$email."' and pass='".$password."'")==1){
			
			
			$json = array();
			$user = $db2->query("select * from User where email='".$email."' and pass='".$password."'")->fetchAll(PDO::FETCH_ASSOC);
    
			$itemObject = new stdClass();
			$itemObject->email = $user[0]['email'];
			$itemObject->namesurname = $user[0]['namesurname'];
			$itemObject->userid = $user[0]['userid'];
			$itemObject->gender = $user[0]['gender'];
			$itemObject->username = $user[0]['username'];
			$itemObject->description = $user[0]['description'];
			$itemObject->profilephoto = $user[0]['profilePhoto'];
			$itemObject->website = $user[0]['website'];
			$itemObject->phonenumber = $user[0]['phoneNumber'];
			$itemObject->registerdate = $user[0]['registerDate'];
			$itemObject->verified_user = $user[0]['verified_user'];
			$itemObject->private_mode = $user[0]['private_mode'];
			$itemObject->business_mode = $user[0]['business_mode'];
			
			array_push($json, $itemObject);
			
			$response = array('user' => $json);
			echo json_encode($response, JSON_PRETTY_PRINT);
			header('Content-Type: application/json');
			
			
			
			
			//jsonobject üret
		}else{
			echo "101";
		}
		/*
			100 - kullanıcı adı ve şifre doğru
			101 - kullanıcı adı veya şifre hatalı
			102 - pdo exception
		
		*/
		
	}catch(PDOException $e){
		echo "102";
	}
	

}else{
	echo "103";
			
}

?>