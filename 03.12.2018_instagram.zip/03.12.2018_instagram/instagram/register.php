<?php
require_once("class.database_sqlite.php");


if($_SERVER['REQUEST_METHOD']=="POST"){


$email = $_POST['email'];
$password= $_POST['password'];
$namesurname = $_POST['namesurname'];
$username = $_POST['username'];
$kayit_tarih = 	 date("d.m.Y H:i:s");
$ip = "127.0.0.1";


	//header('Content-Type: application/json');
	global $db2;
	try{
	
		// eğer mail adresi kayıtlıysa bunu, değilse bunu yap
		if(selectCountInTable_OptionalValues_sqlite("User","email='".$email."'")==0){
			if($email!="" && $password!="" && $username!="" && $namesurname!=""){
				executeSqlite("insert into User VALUES (NULL,'".$username."','".$email."','".$password."','".$namesurname."','','','','','','','',0,0,0)");
				echo "ok";
			}else{
				echo "-1";
			}
		}
	}catch(PDOException $e){
		echo "-2";
	}
	

}else{
	echo "-3";
}

?>